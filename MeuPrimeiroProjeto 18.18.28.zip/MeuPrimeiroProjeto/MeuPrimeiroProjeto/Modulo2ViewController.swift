//
//  Modulo2ViewController.swift
//  MeuPrimeiroProjeto
//
//  Created by Admin on 04/10/21.
//

import UIKit

class Modulo2ViewController: UIViewController {

    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var image: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    

}
