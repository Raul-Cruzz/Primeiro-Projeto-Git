//Criacao de matrizes ou Arrays

//var players: [String] = ["Raul", "Gomes", "Cruz", "Rafael"] // -> Array - bloco de caracteres - colecao
//
//print(players.isEmpty) // isEmpty, checa se a variável é vazia ou nao.
//              // Count - conta os elementos
//              // condicao if para saber a quantidade de elementos se é menor que 5 através do tipo .count
//if players.count <= 5 {
//    print("é menor")
//}else{
//    print("nao é menor")
// para contar os elementos do nosso Array
//players.count



//---



// Acessando Arrays

//var firstPlayer = players.first // checando Array, essa variável trás o primeiro elemento do Array
//var lastPlayer = players.last //" max e  min - first e last " formas de extrair o primeiro e o ultimo nome
//
//
//print([2,3,1].first) // elementos ficam no index, mas o index é diferente do valor em si, os valores sao diferentes
//print([2,3,1].last)
//
//var FirstPlayer = players[0] // Acessando o Array atraves do subscreen, extraindo o elemento especifico.
//
//let numberPlayersSlice = players[1...2] // forma de acessar o array utilizando o contable ranger, conta os elementos de 1 em diante, sem modificar o array.
//
//var hasPlayer = players.contains("Raul") // forma de saber se o Array contem o elemento "Raul", caso nao tenha ele informa que é false
//
//print(players)
//
// Modificando o Array - adicionando um index e passando a ficar com 5 elementos.
//
//var newplayers = players.append("Maria")
//
//players.append("Maria") - Outras formas de adiconar um index e aumentar os elementos.
//players += ["Cruz"]
//
// Forma de incluir o index no Array e escolher a posicao na qual queremos colocar ele.
//
//players.insert("Karina", at: 1)
//
//print(players)



//---



// Removendo Elementos

//print("Antes:  ",players)
//
//var removeElen = players.removeLast() // removendo o último index
//print(removeElen)
//
//removeElen = players.remove(at: 2) // Escolhendo qual elemento será removido
//print(removeElen)
//
//print("Depois  ",players)
//
// removendo um index específico utilizando o optional e Unwrapping
//
//var getIndexPlayer = players.firstIndex(of: "Karina") // declaracao do tipo optional ?
//
//var removePlayer: String = ""
//
//if let getIndexPlayer = getIndexPlayer { // trabalhando com o Unwrapping se a operacao nao for valida retonar nil
//    removePlayer = players.remove(at: getIndexPlayer)
//}
//
//print("RemovePlayer  :",removePlayer)

// Updating Elen - Atualizacao dos Elementos

//var players: [String] = ["Raul", "Gomes", "Cruz", "Rafael"] // Array
//
//players[3] = "Karina" // atualizando o terceiro elemento de Rafael para Karina
//
//players[0...2] = ["Pedro", "Raul", "Rafael"] // Utilizando o countable range para atualizar mais de um elemento de uma só vez
//
//print(players)


//---


// Movendo Elementos

// Forma antiga de alterar a posicao dos elementos

//let playerNewFirst = players.remove(at: 1)
//
//players.insert(playerNewFirst, at: 0)

// Nova forma de alterar a posicao dos elementos

//players.swapAt(0, 2)
//
//print(players)

// forma de realizar a alteracao utilizando o unwraping e retornando o optional, se caso nao retornar nada ele printa nil.

//var indexNewFirst = players.firstIndex(of: "Pedro")
//var indexOtherPlayer = players.firstIndex(of: "Karina")
//
//if let indexNewFirst = indexNewFirst, let indexOtherPlayer = indexOtherPlayer {
//    players.swapAt(indexNewFirst, indexOtherPlayer)
//}
//
//print(players)

// Para ordenar uma cópia dos elementos de forma alfabética.

//players.sort()

// Utilizando o loop for in para extrair os index dos elementos.

//for player in players {
// print(player)
//}



//----



//Dicionario Parte 1

//var players: [String] = ["Raul", "Gomes", "Cruz", "Rafael"] // Array

//Dicionário nao é ordenado como o Array, a String se torna a chave e o Double o valor.

var players: [String: Double] = ["Raul": 20.0, "Gomes": 30.0, "Cruz": 25.0, "Rafael": 15.0] // Dicioário

//print(players)

// sem inserir o tipo
//var players = ["Raul": 20.0, "Gomes": 30.0, "Cruz": 25.0, "Rafael": 15.0] // Dicioário

// para esvaziar o dicionário
//players = [:]
//// para saber se realmente está vázio.
//players.isEmpty - sempre utilizar essa forma como melhor performace
// para contar os elementos do nosso dicionário
//players.count

// para extrair a chave utilizamos o unwrapinge e force! para que o xcode entenda qual chave queremos extrair.
print(players["Raul"]!)

// realizando a operacao utilizando o optional, embrando que se errar o valor ele retorna nil

if let pointsPlayer = players["Raul"] {
    print(pointsPlayer)
}

//Removendo a chave e o valor "Raul": 20.0 da colecao do dicionário

//players["Raul"] = nil

print(players)



//----



//Dicionário Parte 2

//Outra forma de remover uma chave e o valor

//players.removeValue(forKey: "Raul")

//Adicionando chave e valor
//players["Raul"] = 50.0
//Outra forma de adicionar chave e valor, utilizando o optional unwraping e force!, caso de erro retorna nil (Valor nulo)
let olPoints = players.updateValue(60.0, forKey: "Raul")

if let olPoints = olPoints {
    print(olPoints)
}

print(players)

// forma de interagir as chaves e valores
//for (player, points) in players {
//    print("player =>\(player) - points => \(points)")
//}

// forma de interagir as chaves, - colecao nao ordenada

//for player in players.keys {
//    print("player =>\(player)")
//}

// forma de interagir os valores.

for points in players.values {
    print("points =>\(points)")
}

