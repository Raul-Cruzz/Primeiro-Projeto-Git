import Foundation

class Recipe {
    let title: String
    unowned let cooker: Cooker // referencia fraca
    weak var chef: Chef?      // referencia fraca
    // Após utilizar o weak as duas classes foram desalocadas da memória realizando o print na tela, resolvendo o problema de memoria lik.ß
    init(title: String, cooker: Cooker) {
        self.title = title
        self.cooker = cooker
    }
    
    // Utilizando a referencia fraca na Clousere. - Lazy var váriavel preguicosa, só aparece quando é chamada.
    lazy var description: () -> String = { [weak self] in
        "\(self?.title) by \(self?.cooker.name)"
        
    }
    
    deinit {
        print("Goodbye Recipe \(title)")
    }
}

class Chef {
    let name: String
    var recipes: [Recipe] = []
    
    init(name: String) {
        self.name = name
    }
    
    deinit {
        print("Goodbye Chef \(name)!")
    }
}

// Gerenciamento de memória - parte 2

class Cooker {
    let name: String
    var recipes: [Recipe] = []
    
    init(name: String) {
        self.name = name
    }
    
    deinit {
        print("Goodbye chef \(name)!")
    }
}

// Gerenciamento de memória - parte 3. Utilizando o option na clausure retornando nil - valor nulo  por conta da variável nao existir
let description: () -> String

do { // instrucao DO declara o bloco abaixo da classe, finalizando a sua instancia.
    let cooker = Cooker(name: "Gomes")
    let recipe = Recipe(title: "Gerenciamento Memória", cooker: cooker)
    description = recipe.description
    
    /* let chef = Chef(name: "Raul!")
    cooker.recipes.append(recipe)
    recipe.chef = chef
    chef.recipes.append(recipe) */
    
}

print(description())
// Desalocando todas as classes da memória e deixa o contador com 0 de referencia, evitando também o memória lik.
