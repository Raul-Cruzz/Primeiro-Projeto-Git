import UIKit

var string = "var do tipo string, recebe apenas texto"

let count: Int = 10

var saldo: Int = 10

var result = count + saldo

//count = count + 1 => erro

saldo = saldo + 1
