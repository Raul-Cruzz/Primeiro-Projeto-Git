import UIKit

var greering = "Hello, playground"

2 + 3
10 - 5
2 * 5
10 / 2
128 % 10

cos (135 * Double.pi / 100)

max(30, 80)

min(30, 80)

 // Anotacoes de estudo //

/*var number: Int = 3

var name: String = ""


greering = name

//var count: Double = 3.14

number = Int(count)

var count = 3 as Double

print(type(of: count))

number = Int(count)

let count: Int = 15

var saldo: Int = 7

saldo = 10

saldo += 4

saldo -= 3

saldo = saldo + 3

saldo = saldo - 4

saldo *= 2

saldo /= 2

var result = saldo > count

result = count > saldo

result = count == saldo

var apple: Bool = true
var android: Bool = false
var xiaomi = true

result = apple && xiaomi

true && true
true && false
false && false
false && true

var testOR = false
var ORTestr = true

result = testOR || ORTestr

var beer = false

!beer

result = count != saldo */
