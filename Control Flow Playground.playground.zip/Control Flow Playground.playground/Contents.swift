import Foundation

var greeting = "Hello, playground"

let yes: Bool = true
let no: Bool = false

var OneEqualTwo = ( 1 == 2 ) // valor de comparacao

var noOndeEqualTwo = ( 1 != 2 ) // valor nao ou diferente

var isTrue = !( 1 != 2 ) // valor de inversao

// <  > menor e maior que
let isEightGreaterThanNine = ( 8 > 9 )
let isEightLessThanNine = ( 8 < 9 )

// <=  >= menor ou igual e maior ou igual
var x = 8
var y = 9
let isEightGreatEqualerThanNine = ( x >= y )
let isEightLessEqualThanNine = ( x <= y )

// controlador de operacao and, &&, e - compara os valores e retonar o valor real da operacao.
let a = true && true
let b = true && false
let c = false && false

// controlador de operacoes ou, or, || - compara os valores e diz qual é verdadeiro ou faldo.
let d = true || false
let e = false || false
let f = true || true

// trabalhando com mais de uma condicao em extrair um ou dois valores dependendo se o operador for and && ou se for o or ||.
let andOR = 8 < 9 || 8 > 9

// igualdade de String, trabalhando com comparacao de String.
let firstName = "Raul"
let secondName = "Gomes"

let isEqual = firstName == secondName

// para saber a ordem alfabética das Strings
let order = firstName < secondName

// toggle() - alterar o valor da váriavel do tipo string com o operador booleano.
var switchState = true
let g = !switchState // invetendo o valor para a váriavel g atráves do operador ! diferente e a saída sendo false. Nesse caso nao altera o conteúdo mas sim os valores.
switchState.toggle() // - Altera apenas o conteúdo da váriavel.





