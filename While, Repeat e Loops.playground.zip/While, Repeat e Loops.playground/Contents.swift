import Foundation

var count = 7

//Loop while

 while count < 7 {
    print(count)
    count += 1
}

while true {
    print(count)
    count += 1
    
    if count == 10 {
        break
    }
}

//Loop repeat

//repeat {
//    print(count)
//    count += 1
//} while count < 7
//
//let range = 0..<4

// loop for in - mais utilizado

//for x in 0...5 {
//    print(x)
//}

//var sum = 0

//for x in 0...count { // Constante x, count recebe o valor de 7
//    print(x)
//    sum += x // Utilizando o sinal de + para somar todos os números e utilizando a variável sum para aumentar a somatória.
//}
//
//print(sum)

// Omitindo`a constante

//for _ in 0...count {
//    var c = count + 1 // forma do calculo, 0 + 1, 1 + 1 = 2...
//    sum += c // forma do calculo, 2 + 2, 4 + 2...
//}
//
//print(sum)  // posso incluir o atributo < para que ele nao inclua o valor da variável count = 7, e assim diminui a minha conta no loop.

// Loop Switch case - esse loop é melhor que o loop if e else, por se tratar de uma contagem de blocos.

//var count = 7
//var sum = 0
//
//switch count {
//    case 0, 7:  // dois parametros
//        print("0")
//    case 2: // um parametro
//        print("2")
//    case 3...7: // - com o countable range ele nao cai no default porque ele conta o número 3 e printa o número na tela, sem o coutable < ele nao conta o número 3 e cai direto no default.
//        print("3")
//    default:
//        print("defaut")
//
//}

// Segunda forma de utilizar o switch case

//var txt = ""
//switch count {
//case 0:
//    txt = "0"
//case 2:
//    txt = "2"
//case 3...7: // dois parametros 3. 7 -> 3 ou 7
//    txt = "3"
//default:
//    txt = "default"
//}

//print(txt)
//
//var state = true
//
//if state == true {
//    print("Allow access")
//} else {
//    print("Deny access")
//}

